# Global Solution - Gabriel, Nícolas e Pedro - SERS - 2025.2

import pandas as pd                 # pip install pandas no terminal para instalar
import numpy as np                  # pip install numpy no terminal para instalar
import matplotlib.pyplot as plt     # pip install matplotlib no terminal para instalar


# Configuração e Geração de Datas
np.random.seed(42)
datas = pd.date_range(start='2024-01-01', end='2024-12-31 23:00:00', freq='h')
df = pd.DataFrame({'Data': datas})
df['Mes'] = df['Data'].dt.month
df['Hora'] = df['Data'].dt.hour
df['DiaSemana'] = df['Data'].dt.dayofweek
df['Eh_Dia_Util'] = df['DiaSemana'] < 5

# Simular Consumo (Opção A - Análise de Dados)
def simular_consumo(row):
    # Consumo basal (standby) vs Operacional (ar condicionado, luzes)
    basal = np.random.normal(5, 1) 
    operacional = 0
    if row['Eh_Dia_Util'] and 8 <= row['Hora'] <= 18:
        operacional = np.random.normal(25, 5)
        # Sazonalidade: Ar condicionado no verão
        if row['Mes'] in [1, 2, 12]: operacional *= 1.3
        elif row['Mes'] in [6, 7]: operacional *= 0.8
    return basal + operacional

df['Consumo_kWh'] = df.apply(simular_consumo, axis=1)

# Simular Geração Solar (Opção C - Renováveis)
def simular_solar(row):
    if 6 <= row['Hora'] <= 18:
        # Curva de geração solar (pico ao meio-dia)
        intensidade = np.sin((row['Hora'] - 6) * np.pi / 12)
        fator_sazonal = 1 + 0.3 * np.cos((row['Mes'] - 1) * 2 * np.pi / 12)
        clima = np.random.uniform(0.7, 1.0) # Nuvens
        return max(0, 20 * intensidade * fator_sazonal * clima)
    return 0

df['Geracao_Solar_kWh'] = df.apply(simular_solar, axis=1)

# Exportar Dados e Resultados
# Salva em CSV
df.to_csv('dados_energia_projeto.csv', index=False)

# Salva em Excel
df.to_excel('dados_energia_projeto.xlsx', index=False)

print("\nArquivos CSV e XLSX gerados com sucesso!")
print(f"\nEconomia Anual Estimada: R$ {(df['Geracao_Solar_kWh'].sum() * 0.75):.2f}\n")